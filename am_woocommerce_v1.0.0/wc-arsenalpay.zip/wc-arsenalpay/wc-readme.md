# ArsenalPay for Woocommerce of Wordpress CMS

[Arsenal Media LLC](http://www.arsenalmedia.ru/index.php/en)

[Arsenal Pay processing server]( https://arsenalpay.ru/)



## Version
1.0.0


Basic feature list:

 * Module allows seamlessly integrate payment frame to your site 
 * New payment method will appear to pay for your products and services 
 * Support several payment methods ( mobile commerce and bank aquiring ). More are intended to be added
 
## How to install
1. Download zip archive
2. Login to the Wordpress admin section 
3. Go to Plugins>Add new>Download Plugin and choose the right location of plugin archive
4. Click "Install" and then "Activate" the payment module


## Settings
1. Go to Woocommerce>Payment
2. There choose ArsenalPay method.
3. Make proper settings and save


## How to uninstall
1. Go to Plugins and find ArsenalPay 
2. Click on Deactivate. Further you can delete files from your server clicking on Delete.

## Usage
 



 
